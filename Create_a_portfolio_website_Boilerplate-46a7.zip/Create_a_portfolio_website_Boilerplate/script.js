// script.js - Simple Portfolio Script
